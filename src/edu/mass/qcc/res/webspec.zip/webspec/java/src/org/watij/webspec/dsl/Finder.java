package org.watij.webspec.dsl;

/**
 * Created by IntelliJ IDEA.
 * User: bknorr
 * Date: Nov 29, 2010
 * Time: 1:18:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Finder {
    public Tag find(String tag);
}
