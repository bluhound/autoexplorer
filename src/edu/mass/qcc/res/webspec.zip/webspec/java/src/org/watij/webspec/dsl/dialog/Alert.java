package org.watij.webspec.dsl.dialog;

import org.watij.webspec.dsl.WebSpec;

public class Alert extends Dialog {
    public Alert(WebSpec spec) {
        super(spec);
    }
}
