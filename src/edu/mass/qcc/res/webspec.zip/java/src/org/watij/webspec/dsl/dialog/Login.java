package org.watij.webspec.dsl.dialog;

import org.watij.webspec.dsl.WebSpec;

/**
 * Created by IntelliJ IDEA.
 * User: bknorr
 * Date: 12/13/10
 * Time: 10:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class Login extends Dialog {

    public Login(WebSpec spec) {
        super(spec);
    }


}
