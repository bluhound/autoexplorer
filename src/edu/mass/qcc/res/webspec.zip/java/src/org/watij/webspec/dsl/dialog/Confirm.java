package org.watij.webspec.dsl.dialog;

import org.watij.webspec.dsl.WebSpec;

public class Confirm extends Dialog {
    public Confirm(WebSpec spec) {
        super(spec);
    }
}
